print "Hello from ActivePerl!\n";
