package ActivePerl::PPM;

use strict;

our $VERSION = '4.10';

1;
